|Name|Type|Value|Description|
|:---|:---|:---|:---|
|IsEnable|u8|0||
|WorldSoundResetVal|f32|2.5||
|WorldSoundSetDefaultVal|f32|0||