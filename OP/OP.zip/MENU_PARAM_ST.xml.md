|Name|Type|Value|Description|
|:---|:---|:---|:---|
|PlayerDeathPostTimer1|f32|2.5||
|PlayerDeathPostTimer2|f32|2||
|Player HP Bar Length Scale|s32|1920||
|Player Mp Bar Length Scale|s32|600||
|Player Sp Bar Length Scale|s32|1920||
|Player Menu Control 1|f32|0.5||
|Player Menu Control 2|f32|0||
|FakeHealth|s32|0||
|FakeMana|s32|0||
|FakeStamina|s32|0||
|MenuFaceRange1|s32|-8||
|MenuFaceRange2|s32|40||
|Unk1|f32|0||
|Unk2|f32|0||
|Unk3|s32|0||
|Unk4|s32|0||
|Unk5|s32|0||
|Unk6|s32|0||
|Unk7|s32|0||
|Unk8|s32|0||
|Unk9|s32|0||
|Unk9|s32|0||
|Unk10|s32|0||
|Unk11|s32|0||
|Unk12|s32|0||
|Unk13|s32|0||
|Unk14|s32|0||
|Unk15|s32|0||
|Unk16|s32|0||
|Unk17|s32|0||
|Unk18|f32|0||
|Unk19|f32|0||
|MenuJobHolder|f32|3.5||
|Unk21|s32|0||
|Unk22|s32|0||
|Unk23|s32|0||
|Unk24|s32|0||
|Unk25|s32|0||
|Unk26|s32|0||
|Unk27|s32|0||
|ResolutionValue1|f32|0||
|ResolutionValue2|f32|0||
|NewMoneyMenuHandle|f32|10||
|NewStaminaMenuHandle|f32|0.5||
