|Name|Type|Value|Description|
|:---|:---|:---|:---|
|Unk1|s32|0||
|EventFlagId1|s32|-1||
|EventFlagId2|s32|-1||
|Header MessageId|s32|-1||
|MessageId|s32|-1||
|Unk2|s32|-1||
