|Name|Type|Value|Description|
|:---|:---|:---|:---|
|ActionId [0-36]|u8|22||
|ActionCorrection|u8|2||
|ReserveArtPointType [0-3]|u8|1||
|UnusedField|u8|2||
|reserveArtsPoint0|s8|-1||
|reserveArtsPoint1|s8|-1||
|reserveArtsPoint2|s8|-1||
|reserveArtsPoint3|s8|-1||
|DebugTextId|s32|70005||
|subFPCost|s16|-1||
|FPCost|s16|0||
|FPCostLight|s16|-1||
|FpCostStrong|s16|-1||
|ShieldCategory [0-4]|u8|0||
