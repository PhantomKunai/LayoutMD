|Name|Type|Value|Description|
|:---|:---|:---|:---|
|CaptionTextId|s32|0||
|IconId|s32|-1||
|RequiredPropertyId|s32|0||
|CompareType|u8|1||
|RequiredPropertyFormatId|u8|0||
|AdhocCaption|fixstrW|耐久度 [18]||