|Name|Type|Value|Description|
|:---|:---|:---|:---|
|DyingEffectInit0|f32|0||
|DyingEffectInit1|f32|0||
|Unk|f32|0||
|DyingEffect_Death|f32|0||
|DyingEffect_Revive|f32|0||
