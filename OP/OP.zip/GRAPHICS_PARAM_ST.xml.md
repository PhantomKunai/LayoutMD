|Name|Type|Value|Description|
|:---|:---|:---|:---|
|Decal Spawn Limitation|f32|0||
|Torch FFX EmissiveIntensityScale|f32|0||
|Torch FFX Model EmissiveIntensityScale|u16|0||
|PlainLightMutex|f32|0||
|ClothSpeed1|f32|0||
|ClothSpeed2|f32|0||
