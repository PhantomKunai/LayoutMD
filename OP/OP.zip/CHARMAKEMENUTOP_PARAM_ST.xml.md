|Name|Type|Value|Description|
|:---|:---|:---|:---|
|CommandID|s32|1||
|FaceParamID|s32|0||
|TableID|s32|0||
|ViewCondition|s32|0||
|PreviewMode|u8|0||
|MenuType|s8|2||
