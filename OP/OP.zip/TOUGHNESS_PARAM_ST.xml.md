|Name|Type|Value|Description|
|:---|:---|:---|:---|
|Toughness|f32|1||
|DamageLvlThreshold|s16|0||
|IsToughnessEffective|u8|0||
|SpEffectId|s32|6352||
