|Name|Type|Value|Description|
|:---|:---|:---|:---|
|R|u8|0||
|G|u8|0||
|B|u8|0||
|A|u8|255||