|Name|Type|Value|Description|
|:---|:---|:---|:---|
|lv01_BorderDist|f32|5||
|lv01_PlayDist|f32|1||
|lv12_BorderDist|f32|20||
|lv12_PlayDist|f32|2||
|textureLod|u8|1||
|lv23_BorderDist|f32|9999||
|lv23_PlayDist|f32|1||
|lv34_BorderDist|f32|9999||
|lv34_PlayDist|f32|1||
|lv45_BorderDist|f32|9999||
|lv45_PlayDist|f32|1||
|DistanceScaleId [0-255]|u8|0||
|UseExtraLayer|u8|0||
|ExtraBorderDist|f32|0.2||
