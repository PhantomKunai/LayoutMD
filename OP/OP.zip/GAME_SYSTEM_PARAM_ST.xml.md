|Name|Type|Value|Description|
|:---|:---|:---|:---|
|BasicToughnessEndurance|f32|0.5||
|Character Turn 90 Degrees Animation Id1|s32|26001||
|Character Turn 90 Degrees Animation Id2|s32|26011||
|Character Turn 180 Degrees Animation Id1|s32|26021||
|Character Turn 180 Degrees Animation Id2|s32|26031||
|Character Turn Speed Limitation 90 Degrees|u16|180||
|Character Turn Speed Limitation 180 Degrees|u16|180||
|DebtItem|s32|490||
|Flick Damage Cut Rate Global Value|f32|1||
|Talk Range 1|f32|180||
|Talk Range 2|f32|180||
|Cult.SpEffectId1|s32|0||
|Unk1|s32|0||
|Cult.SpEffectId2|s32|0||
|Cult.SpEffectId3|s32|0||
|Cult.SpEffectId4|s32|0||
|Cult.SpEffectId5|s32|0||
|Cult.SpEffectId6|s32|0||
|Cult.SpEffectId7|s32|0||
|Cult.LvLUpCeremonySwordState|s32|0||
|Cult.ReallocateAttributesState|s32|0||
|Cult.SwordOfDeceaseState|s32|0||
|Cult.RageCeremonySwordState|s32|0||
|Cult.CeremonyDaySwordState|s32|0||
|Cult.ShiomuCeremonySwordState|s32|0||
|Cult.InvasionBannedCeremonyState|s32|0||
|Cult.TextId1|s32|0||
|Unk2|s32|0||
|Cult.TextId2|s32|0||
|Cult.TextId3|s32|0||
|Cult.TextId4|s32|0||
|Cult.TextId5|s32|0||
|Cult.TextId6|s32|0||
|Unk3|s32|0||
|Cult.TextId7|s32|0||
|Cult.TextId3.EventFlagId|s32|0||
|Cult.EventFlagId|s32|0||
|ChrFinder.UnkSpEffectId|s32|0||
|ChrEstusEatSlot|s32|0||
|ChrSoulEatSlot|s32|0||
|TearsOfDenialTriggerEffect|s32|0||
|Unk4|f32|0||
|Unk5|f32|0||
|MultModeBossValue1|f32|0||
|SoloModeBossValue1|f32|0||
|MultModeBossValue2|f32|0||
|SoloModeBossValue2|f32|0||
|TeamType Name Position Adjustment|u16|0||
|Unk6|u16|0||
|ChrFinder.ShootDmyPolyId|u16|0||
|ChrFinder.TargetsNum|u16|0||
|ChrFinder.DetectTargetsRange|f32|0||
|ChrFinder.InvadeType17_BulletId|s32|0||
|ChrFinder.InvadeType25_BulletId|s32|0||
|ChrFinder.InvadeType23_BulletId1|s32|0||
|ChrFinder.InvadeType22_BulletId|s32|0||
|ChrFinder.InvadeType21_BulletId|s32|0||
|ChrFinder.InvadeType7/21_BulletId|s32|0||
|ChrFinder.InvadeType0-17_BulletId|s32|0||
|ChrFinder.InvadeType23_BulletId2|s32|0||
|ChrFinder.InvadeType21_BulletId|s32|0||
|ChrFinder.InvadeType20_BulletId2|s32|0||
|ChrFinder.InvadeType25_BulletId|s32|0||
|ChrFinder.InvadeType23_BulletId|s32|0||
|ChrFinder.InvadeType22_BulletId|s32|0||
|ChrFinder.InvadeType4/21_BulletId|s32|0||
|ChrFinder.Unused_BulletId|s32|0||
|ChrFinder.InvadeType5_BulletId|s32|0||
|ChrFinder.InvadeType6_BulletId|s32|0||
|DeadChrFinder.BulletId|s32|0||
|ChrFinder.Unk|s32|0||
|Ghost [Transparency] Global Value|f32|0||
|Throw Escape Value|f32|0||
|Unk7|u16|0||
|Unk8|u16|0||
|NetPenalty Condition 1|u16|0||
|Unk9|u16|0||
|NetPenalty Timer [sec]|f32|0||
|NetPenalty Condition 2|u16|0||
|Invasion AFK Timer [sec]|u16|0||
|ChrFinder.Entity_BulletId|s32|0||
|DeadChrFinder.SpEffectId|s32|0||
|DeadChrFinder.Timer[sec]|f32|0||
|FrameRate Value1|f32|0||
|FrameRate Value2|f32|0||
|AddSoloBreakInPoint Max|s32|0||
|Talk Range Global Value|f32|0||
|Server Request Timer [sec]|f32|0||
|BulletEmitterMaxNum|u8|0||
|Unk10|u8|0||
|Host Weakness Compensation|u16|0|H (%. 0 f) * (1 + Rel (%. 0 f) / 100) + Abs (%. 0 f) + WH (%. 0 f) * Wmult (%. 0 f) =%|
|Host Weakness Compensation|u16|0|H (%. 0 f) * (1 + Rel (%. 0 f) / 100) + Abs (%. 0 f) + WH (%. 0 f) * Wmult (%. 0 f) =%|
|Client/Host Weakness Compensation|u16|0|C (%. 0 f) + WC (%. 0 f) * Wmult (%. 0 f) =%. 3 f|
|Summon Sign Value|s32|0||
|MoundMakerSpEffectId|s32|0||
|Unk11|s32|0||
|Unk12|s32|0||
|Unk13|s32|0||
|Unk14|s32|0||
|Unk15|s32|0||
|Unk16|s32|0||
|Unk17|s32|0||
|ServerTimer2[sec]|f32|0||
|Unk18|s32|0||
|Unk19|s32|0||
|Unk20|s32|0||
|Calc Correct Global Adjustment|f32|0||