|Name|Type|Value|Description|
|:---|:---|:---|:---|
|Value|s32|1||
|TextId|s32|11320||
|CompareType|u8|0||
