|Name|Type|Value|Description|
|:---|:---|:---|:---|
|Unk1|s32|-1||
|Unk2|s32|-1||
|Unk3|s32|-1||
|Unk4|s32|-1||
|Unk5|s32|-1||
