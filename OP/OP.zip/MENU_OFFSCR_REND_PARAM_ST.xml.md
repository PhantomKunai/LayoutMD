|Name|Type|Value|Description|
|:---|:---|:---|:---|
|MenuContent0 Y|f32|0||
|MenuContent0 X|f32|0.85||
|MenuContent0 Distance|f32|0||
|MenuContent1 Y|f32|2.66||
|MenuContent1 X|f32|1.719||
|MenuContent1 Reverse X|f32|-14.85||
|MenuContent1 Distance|f32|15||
|screenRendId|s32|11||
