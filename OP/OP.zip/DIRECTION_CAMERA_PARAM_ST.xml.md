|Name|Type|Value|Description|
|:---|:---|:---|:---|
|RumbleState[ON_OFF]|u8|1||
