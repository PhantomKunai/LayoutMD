|Name|Type|Value|Description|
|:---|:---|:---|:---|
|Radius|f32|5||
|lifeFrame|f32|1||
|bSpEffectEnable [ON_OFF]|u8|0||
|Type [AI_SOUND_RATE_TYPE]|u8|0||
|fakeTargetType [AI_SOUND_FAKE_TARGET_TYPE]|u8|1||
|InterestCategory|u8|0||
|UseHitDamageTeam [ON_OFF]|u8|0||
