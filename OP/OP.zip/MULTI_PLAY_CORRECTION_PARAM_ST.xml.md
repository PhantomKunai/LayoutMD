|Name|Type|Value|Description|
|:---|:---|:---|:---|
|CorrectionVal0|s32|140201||
|CorrectionVal1|s32|140202||
|CorrectionVal2|s32|140203||
|CorrectionVal3|s32|0||
