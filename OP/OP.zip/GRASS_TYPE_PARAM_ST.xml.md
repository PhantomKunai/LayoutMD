|Name|Type|Value|Description|
|:---|:---|:---|:---|
|GrassLodRangeParamId|u16|0||
|Type1|u8|1||
|Type2|u8|3||
|Type3|u8|2||
|Unk1|u8|0||
|Unk2|u8|0||
|UseExtra_GrassRate|u8|0||
|GrassDefaultRate|f32|1||
|ObjectReference1|fixstrW|o007090 [32]||
|TextureReference1|fixstrW|o007090_Grass_01_far_a [64]||
|TextureReference2|fixstrW|o007090_Grass_01_far_a [64]||
|Unk3|u8|100||
|Unk3|u8|150||
|GrassAngle|u8|5||
|GrassXZ|u8|90||
|GrassY|u8|110||
|GrassHeight1|u8|90||
|GrassHeight2|u8|110||
|GrassSpVal1|u8|255||
|GrassSpVal2|u8|255||
|GrassSpVal3|u8|255||
|GrassSpVal4|u8|255||
|GrassSpVal5|u8|255||
|GrassSpVal6|u8|255||
|Switch [0,1]|u8|0||
|Unk4|u8|0||
|Unk5|u8|0||
|Unk6|f32|0||
|Unk7|u8|0||
|Unk8|u8|0||
|Unk9|u8|40||
|Unk10|f32|-1||
|Unk11|f32|-1||
|ExtraGrassRate|f32|0.5||
|Unk12|u8|0||
|ObjectReference2|fixstrW|o007090 [32]||