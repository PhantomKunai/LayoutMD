|Name|Type|Value|Description|
|:---|:---|:---|:---|
|AdhocCaption|fixstrW|c0000 [48]||
|Unk|s32|-1||
