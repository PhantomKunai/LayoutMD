|Name|Type|Value|Description|
|:---|:---|:---|:---|
|Unk1|f32|5||
|Unk2|f32|1||
|Unk3|s32|1||
|Unk4|f32|1||
|Unk5|f32|1||
|Unk6|f32|1||
