|Name|Type|Value|Description|
|:---|:---|:---|:---|
|GroundMaterialType [0,1,2,3]|u8|0||
|Unk1|u8|1||
|SpEffectId|s32|-1||