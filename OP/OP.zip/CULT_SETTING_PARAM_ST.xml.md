|Name|Type|Value|Description|
|:---|:---|:---|:---|
|Distance|f32|0.8||
|Angle|f32|90||
|EventFlagId|s32|-1||
|Coefficient.1000|s16|0||
|CultState1|s8|0||
|CultState2|s8|0||
