|Name|Type|Value|Description|
|:---|:---|:---|:---|
|GuideMessageId|s32|-1||
|Unk|u8|1||
