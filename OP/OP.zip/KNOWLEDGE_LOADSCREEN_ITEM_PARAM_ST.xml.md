|Name|Type|Value|Description|
|:---|:---|:---|:---|
|LoadscreenCategoryId|x32|0x00000000||
|KnowledgeId|s32|23000000||
