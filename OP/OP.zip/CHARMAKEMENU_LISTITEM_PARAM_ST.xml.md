|Name|Type|Value|Description|
|:---|:---|:---|:---|
|Value|s32|1||
|CaptionId|s32|0||
|IconID|u8|0||
