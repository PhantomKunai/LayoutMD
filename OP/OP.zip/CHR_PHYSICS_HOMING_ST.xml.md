|Name|Type|Value|Description|
|:---|:---|:---|:---|
|EdgePointAdd_X|f32|1||
|EdgePointAdd_Y|f32|1||
|EdgePointAdd_Z|f32|1||
|Unk|s16|0||
|IsUseExtra|u8|0||
|DontResetParameter|u8|1||
|Extra_Angle|f32|0||
|InitWirePosCondition|u8|1||
|WireCorrectionValue [0,1,2]|u8|0||
|Extra_ForwardDirection|f32|0||
