|Name|Type|Value|Description|
|:---|:---|:---|:---|
|maxAmmount|u8|1||
