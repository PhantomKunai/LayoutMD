|Name|Type|Value|Description|
|:---|:---|:---|:---|
|WirePointSearchParamId1|s32|0||
|WirePointSearchParamId2|s32|0||
|WirePointSearchParamId3|s32|0||
