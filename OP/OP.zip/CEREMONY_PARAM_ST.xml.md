|Name|Type|Value|Description|
|:---|:---|:---|:---|
|EventLayerID|s32|0||
|MapStudioLayerID|s32|0||
|GparamID[Up]|s16|0||
|GparamID[Low]|s16|0||
|Point CloudID|s32|0||
|GI_TextureID|s32|0||
|Light GroupID|s32|0||
|IsReload|u8|0||
|IsDisableOnline|u8|0||
