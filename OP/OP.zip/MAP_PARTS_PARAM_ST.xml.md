|Name|Type|Value|Description|
|:---|:---|:---|:---|
|MapPartFloat1|f32|1||
|MapPartFloat2|f32|1||
