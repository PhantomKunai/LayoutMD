|Name|Type|Value|Description|
|:---|:---|:---|:---|
|ChrBndType|u8|0||
|AniBndType|u8|0||
|TexBndType|u8|0||
|BehBndType|u8|0||
|SndChrType|u8|0||