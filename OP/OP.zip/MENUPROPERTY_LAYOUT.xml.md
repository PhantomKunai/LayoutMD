|Name|Type|Value|Description|
|:---|:---|:---|:---|
|LayoutPath|fixstr|[16]||
|PropertyId [MENU_PROPERTY_ID]|s32|0||
|captionTextId|s32|0||
|HelpTextId|s32|0||
