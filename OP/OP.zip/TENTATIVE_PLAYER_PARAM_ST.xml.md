|Name|Type|Value|Description|
|:---|:---|:---|:---|
|Foot Effect Size Scale|s32|0||
|Player Transparency While Aiming [sec]|f32|0||
|Players ~ Tougou Xizi Ginsengzaki Correction Value|f32|0||
|Maximum Decease Level Possible|u16|0||
|Unk1|u8|0||
|Giant Tree Seed Lottery Condition 1|u8|0||
|Acquisition of a mouthpiece item> Young|s32|0||
|Treasure box item acquisition|s32|0||
|LoadOfCinderSpEffect1|s32|0||
|LoadOfCinderSpEffect2|s32|0||
|LoadOfCinderSpEffect3|s32|0||
|LoadOfCinderSpEffect4|s32|0||
|LoadOfCinderSpEffect5|s32|0||
|Damage Reduction [0:1]|f32|0||
|Status shortage Stamina budget plant|f32|0|StaminaConsumeRate|
|StaggerGlobalValue|s16|1||
|CalcCorrectGraph|u16|0||
|LoadOfCinderSpEffect1 (Hinasaki)|s32|0||
|LoadOfCinderSpEffect2 (Hinasaki)|s32|0||
|LoadOfCinderSpEffect3 (Hinasaki)|s32|0||
|LoadOfCinderSpEffect4 (Hinasaki)|s32|0||
|LoadOfCinderSpEffect5 (Hinasaki)|s32|0||
|StaminaConsumeCondition|s32|0||
|Unk12|s32|0||
|HP/MP_EstusAllocateRate|f32|0||
|GiantTreeSeedLotteryCondition 2|u8|0||
|Giant Tree Seed Lottery|u8|0||
|GestureValue?|u8|0||
|EquipLoadParameter1|u8|0||
|EquipLoadParameter2|u8|0||
|EquipLoadParameter3|u8|0||
|EquipLoadParameter4|u8|0||
|EquipLoadParameter5|u8|0||
|ChrFinder.UpdateTeamTypeByGiantTreeSeedEffect|s32|0||
|MultiPlayerSuccessEffectId|s32|0||
|RangeWeaponPartsLoader|s32|0||
|ArrowLimitWpPrm1|u8|0||
|ArrowLimitWpPrm2|u8|0||
|Unk2|u8|0||
|Unk3|u8|0||
|PlayerResistVal1|f32|0||
|PlayerResistVal2|f32|0||
|PlayerResistVal3|f32|0||
|PlayerResistVal4|f32|0||
|PlayerResistVal5|f32|0||
|PlayerResistVal6|f32|0||
|PlayerResistVal7|f32|0||
|PlayerResistVal8|f32|0||
|PlayerResistVal9|f32|0||
|PlayerResistVal10|f32|0||
|ActionRequest|f32|0||
|BossDefeatEmberSpEffectId|s32|0||
|PvPMatchMpEstusAllocationRate|f32|0||
|PvPMatchMpEstus|s32|0||
|PvPMatchHpEstusAllocationRate|f32|0||
|PvPMatchHpEstus|s32|0||
|PvPMatchHp/MpEstusAllocationRate|f32|0||
|PvPMatchHp/MpEstus|s32|0||
|HpEstusAllocateRate|f32|0||
|HpEstusAllocateNum|s32|0||
|MpEstusAllocateRate|f32|0||
|MpEstusAllocateNum|s32|0||
|Unk4|s32|0||
